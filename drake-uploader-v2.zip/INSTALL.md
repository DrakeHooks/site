# Drake archive uploader v2 — transfer and publish

This package ships `tools/uploader/` for the **public** `DrakeHooks/site` repository. It does **not** contain your current `.env`, SSH private keys, uploaded media, or Git working tree.

**Current known host layout:** Alpine LXC 102, `/opt/drakehooks/uploader` (old app), `/opt/drakehooks/archive-site` (Hugo checkout), `/mnt/pve/mnt/media/drakehooks-uploads` (temporary uploads), port `8011`, hostname `upload.drakehooks.net`.

**Mac:** extract this ZIP locally. Transfer it to Alpine, substituting the actual container IP if it has changed:

```sh
scp ~/Downloads/drake-uploader-v2.zip root@192.168.86.208:/root/
```

**Alpine LXC console:**

```sh
apk add --no-cache unzip
mkdir -p /root/drake-uploader-v2
unzip -oq /root/drake-uploader-v2.zip -d /root/drake-uploader-v2
cd /root/drake-uploader-v2
sh ./publish-and-deploy.sh
```

This helper:

1. Verifies the existing credentials without printing them, storage mount, Git checkout, and clean `main` branch.
2. Stops if there are leftover original files in the legacy staging folders; inspect those before switching.
3. Makes a fresh **private** backup of the existing uploader, including its credentials.
4. Copies only `tools/uploader/` into the site checkout (no `.env` or images).
5. Commits and pushes those code files to the site's GitHub `main` branch using your server's **existing** credentials.
6. Builds/replaces the `drake-uploader` container and adds `drake-uploader-worker`.
7. Checks the local `/health` endpoint.

The existing tunnel/NGINX target `localhost:8011` does not change. GitHub Pages can rebuild after the code-only commit, but `tools/uploader/` is not used as Hugo content.

**Rollback** (run if deployment fails):

```sh
cd /opt/drakehooks/archive-site/tools/uploader
# Stop the new worker before returning to the old implementation.
docker compose stop worker
cd /opt/drakehooks/uploader
docker compose up -d --build
```

The previous service remains at `/opt/drakehooks/uploader`. Rollback does not undo the code commit; it only returns the service to the previous image. If using legacy uploads again, avoid running both workers.

**Next code updates:**

```sh
cd /opt/drakehooks/archive-site
git pull --ff-only origin main
cd tools/uploader
docker compose up -d --build
```

**Check operation:**

```sh
docker compose -f /opt/drakehooks/archive-site/tools/uploader/docker-compose.yml ps
docker logs --tail 80 drake-uploader
docker logs --tail 80 drake-uploader-worker
wget -qO- http://127.0.0.1:8011/health
```

The uploader is **not running on your server until you execute the install commands**. I cannot access your Proxmox console from this chat.
