#!/bin/sh
# Safely install the code under the existing Hugo repository, publish to GitHub,
# and recreate the existing Docker Compose project without changing tunnels.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
SOURCE="$ROOT/tools/uploader"
REPO=/opt/drakehooks/archive-site
OLD=/opt/drakehooks/uploader
DEST="$REPO/tools/uploader"
DATA=/mnt/pve/mnt/media/drakehooks-uploads
STAMP=$(date -u '+%Y%m%d-%H%M%S')
BACKUP="/root/uploader-backups/v2-predeploy-$STAMP"

[ "$(id -u)" -eq 0 ] || { echo "Run as root inside Alpine LXC" >&2; exit 1; }
[ -f "$SOURCE/docker-compose.yml" ] || { echo "Missing release files" >&2; exit 1; }
[ -f "$OLD/.env" ] || { echo "Missing existing private $OLD/.env" >&2; exit 1; }
[ -d "$DATA" ] || { echo "Upload storage mount $DATA is missing" >&2; exit 1; }
[ -d "$REPO/.git" ] || { echo "Missing Git checkout $REPO" >&2; exit 1; }
command -v docker >/dev/null || { echo "Docker not installed" >&2; exit 1; }
command -v git >/dev/null || { echo "Git not installed" >&2; exit 1; }

if ! grep -Eq '^(UPLOAD_USER|ARCHIVE_USER)=[^[:space:]]+' "$OLD/.env" || \
   ! grep -Eq '^(UPLOAD_PASS|ARCHIVE_PASS)=[^[:space:]]+' "$OLD/.env"; then
  echo "Expected existing UPLOAD_USER/UPLOAD_PASS or ARCHIVE_USER/ARCHIVE_PASS in .env." >&2
  echo "No changes were made. Do not put credentials into Git." >&2
  exit 1
fi

# Old folders can contain staged jobs that the new worker does not understand.
for c in archive birds; do
  if [ -d "$DATA/$c" ]; then
    pending=$(find "$DATA/$c" -type f -print -quit)
    if [ -n "$pending" ]; then
      echo "Legacy staging still has files in $DATA/$c. Process or relocate them before cutover." >&2
      echo "Example: $pending" >&2
      exit 1
    fi
  fi
done

[ "$(git -C "$REPO" rev-parse --abbrev-ref HEAD)" = "main" ] || {
  echo "Git checkout must be on main" >&2; exit 1;
}
[ -z "$(git -C "$REPO" status --porcelain)" ] || {
  echo "Git checkout has uncommitted files. Resolve them first." >&2; exit 1;
}
git -C "$REPO" fetch origin main
git -C "$REPO" merge --ff-only origin/main
[ "$(git -C "$REPO" rev-parse HEAD)" = "$(git -C "$REPO" rev-parse origin/main)" ] || {
  echo "Git checkout has unpushed commits. Stop and inspect." >&2; exit 1;
}

mkdir -p "$BACKUP"
chmod 700 "$BACKUP"
tar -C /opt/drakehooks -czf "$BACKUP/old-uploader.tar.gz" uploader
chmod 600 "$BACKUP/old-uploader.tar.gz"
echo "Backup: $BACKUP/old-uploader.tar.gz"

mkdir -p "$DEST"
cp -R "$SOURCE/." "$DEST/"
# Defense in depth, even if someone added a local .env to the source tree.
rm -f "$DEST/.env"

git -C "$REPO" add -- tools/uploader
git -C "$REPO" diff --cached --check
if [ -n "$(git -C "$REPO" diff --cached --name-only)" ]; then
  git -C "$REPO" -c user.name='Drake Hooks' \
    -c user.email='uploader@users.noreply.github.com' \
    commit -m 'Add versioned archive uploader v2'
  git -C "$REPO" push origin main
else
  echo "Uploader source already matches GitHub; deploying existing code."
fi

cd "$DEST"
docker compose config --quiet
docker compose up -d --build

echo "=== DOCKER ==="
docker compose ps

echo "=== LOCAL HEALTH ==="
# Containers may take a moment to bind the port; this is only a local probe.
i=0
while [ "$i" -lt 12 ]; do
  if wget -qO- http://127.0.0.1:8011/health; then
    echo
    echo 'DEPLOY COMMANDS COMPLETED. Check that web, ingest, data, repo are true.'
    exit 0
  fi
  i=$((i + 1))
  sleep 2
done

echo "The container did not answer its local health endpoint." >&2
echo "Read: docker logs --tail 100 drake-uploader" >&2
exit 1
